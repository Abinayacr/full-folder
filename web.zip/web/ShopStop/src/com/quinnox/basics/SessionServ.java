package com.quinnox.basics;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServ")
public class SessionServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public SessionServ() {
        super();   
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try{
			 response.setContentType("text/html");
			 PrintWriter pw=response.getWriter();
			 String user=request.getParameter("u");
			 String password=request.getParameter("p");
			 if(user.equals("acr") && password.equals("redhat"))
			 {
				 pw.print("Welcome"+user);
				 pw.println("<br><br>");
				 pw.print("here is ur passwd:"+password);
				 pw.println("<br><br>");
				 HttpSession session=request.getSession();
				 session.setAttribute("usname", user);
				 session.setAttribute("uspass", password);
				 pw.println("session id id:"+session.getId()+"<br/>");
				 pw.println("time is:"+session.getLastAccessedTime()+"<br/>");
			 }
			 else{
				 pw.println("<html><body text='red'><h3>Login failed</h3></body></html>");
				 RequestDispatcher rd=request.getRequestDispatcher("Login.html");
				 rd.include(request,response);
			 }
			 pw.print("<a href='SessionWelcome'>view</a>");
			 pw.close();
		 }catch(Exception e){
			 System.out.println(e);
		 }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 doGet(request,response);
	}

}

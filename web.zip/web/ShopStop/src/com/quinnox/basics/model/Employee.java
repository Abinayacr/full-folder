package com.quinnox.basics.model;

public class Employee 
{
	private int empno;
	private String empname;
	private String desig;
	
	public int getEmpno() 
	{
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}
}

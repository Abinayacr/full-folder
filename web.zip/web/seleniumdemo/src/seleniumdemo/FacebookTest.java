package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookTest {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","D:\\ABINAYA\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.getTitle();
		driver.navigate().to("https://news.rediff.com/commentary/2019/aug/31/liveupdate");
		
		driver.navigate().back();
		driver.navigate().refresh();
		
		Thread.sleep(5000);
		
		driver.findElement(By.name("email")).sendKeys("arjunm801@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("******");
		driver.findElement(By.id("u_0_a")).click();
		
		//driver.quit();
	}

}

package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class First {
	public static void main(String[] args){
		System.setProperty("webdriver.chrome.driver","D:\\ABINAYA\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("http://www.google.com/");
		
		driver.findElement(By.name("q")).sendKeys("quinnox.banglore");
		
		driver.findElement(By.name("btnK")).click();
	}

}
